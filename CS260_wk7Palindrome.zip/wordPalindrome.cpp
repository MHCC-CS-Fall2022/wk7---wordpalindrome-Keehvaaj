/*

*/

#include <iostream>   // Provides std::
#include <cstdlib>    // Provides NULL and size_t
#include <cstring>     // Provides toupper, isalpha
#include "node.h"
#include <stack>
#include <queue>
using namespace std;

void repeat(int&);
//Pre-Condition: Needs user input to continue to check
//palindrome
//Post-condition: Uses user input to continue or break loop.
void process(queue<string> ,stack<string>);//queue<string>, stack<string>);
//Pre-condition: needs a queue and stack to figure out if
//sentence is a palindrome.
//Post-condition: Should display if user input is
//a palindrome or not

int main()
{
    stack<string> sentence;
    queue<string> phrase;
    int option = 0;
    do
    {
        //if(cnt == 0)
        cout << "\nPress Enter to start\n\n";
            cin.ignore(80,'\n');
        process(phrase, sentence);
        while(!phrase.empty())
        {
            phrase.pop();
        }
        while(!sentence.empty())
        {
            sentence.pop();
        }
        repeat(option);
    }while(option != 2);

    return 0;
}


void repeat(int& opt)
{
    cout << "\nWould you like to enter a sentence?\n";
    cout << "\n| 1 - YES | 2 - NO |\n";
    cin.ignore();
    cin >> opt;
    cout << endl << endl;
}

void process(queue<string> phrase, stack<string> sentence)//queue<string>& phrase, stack<string>& sentence)
{
    string input;
    int wrong = 0;
    //stack<string> sentence;
    //queue<string> phrase;

    cout << "\nEnter in a sentence to check if its a palindrome.\n";
    while(cin.peek() != '\n')
    {
        cin >> input;
        phrase.push(input);
        sentence.push(input);
    }

    while((!phrase.empty()) && (!sentence.empty()))
    {
        if(phrase.front() != sentence.top())
        {
            wrong++;
            cout << phrase.front() << endl;
            cout << sentence.top() << endl;
        }
        phrase.pop();
        sentence.pop();
    }

    if(wrong == 0)
        cout << "\n\nPalindrome!!\n";
    else
        cout << "\n\nNo Palindrome\n";
    return;
}
